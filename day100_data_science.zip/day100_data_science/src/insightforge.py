"""CSV profiling, descriptive statistics, correlations, and HTML report generation."""

from __future__ import annotations

import csv
import html
import json
import math
import statistics
from collections import Counter
from pathlib import Path
from typing import Any


def _is_number(value: str) -> bool:
    if not value.strip():
        return False
    try:
        number = float(value)
        return math.isfinite(number)
    except (TypeError, ValueError):
        return False


def _to_number(value: str) -> float | None:
    if not value.strip() or not _is_number(value):
        return None
    return float(value)


def _fmt_num(value: float | int | None) -> str:
    if value is None:
        return "—"
    if isinstance(value, int):
        return str(value)
    return f"{value:,.3f}".rstrip("0").rstrip(".")


def _quantile(values: list[float], q: float) -> float:
    ordered = sorted(values)
    if not ordered:
        raise ValueError("Cannot calculate quantile for an empty list.")
    position = (len(ordered) - 1) * q
    low = math.floor(position)
    high = math.ceil(position)
    if low == high:
        return ordered[low]
    return ordered[low] + (ordered[high] - ordered[low]) * (position - low)


def _correlation(xs: list[float], ys: list[float]) -> float | None:
    if len(xs) != len(ys) or len(xs) < 3:
        return None
    mean_x, mean_y = statistics.mean(xs), statistics.mean(ys)
    dx = [x - mean_x for x in xs]
    dy = [y - mean_y for y in ys]
    denom_x = math.sqrt(sum(v * v for v in dx))
    denom_y = math.sqrt(sum(v * v for v in dy))
    if denom_x == 0 or denom_y == 0:
        return None
    return sum(a * b for a, b in zip(dx, dy)) / (denom_x * denom_y)


def analyze_rows(headers: list[str], rows: list[dict[str, str]]) -> dict[str, Any]:
    """Analyze already-loaded CSV rows. Useful as a testable public API."""
    if not headers:
        raise ValueError("The CSV file must include a header row.")
    if len(set(headers)) != len(headers):
        raise ValueError("CSV column names must be unique.")
    if not rows:
        raise ValueError("The CSV file must contain at least one data row.")

    clean_rows: list[dict[str, str]] = []
    for row in rows:
        clean_rows.append({h: (row.get(h) or "").strip() for h in headers})

    missing_by_column = {
        h: sum(1 for row in clean_rows if not row[h])
        for h in headers
    }
    numeric_columns: list[str] = []
    categorical_columns: list[str] = []
    column_details: dict[str, Any] = {}

    for header in headers:
        values = [row[header] for row in clean_rows if row[header]]
        parsed = [_to_number(value) for value in values]
        is_numeric = bool(values) and all(value is not None for value in parsed)
        if is_numeric:
            numeric_columns.append(header)
            nums = [value for value in parsed if value is not None]
            column_details[header] = {
                "type": "numeric",
                "non_missing": len(nums),
                "missing": missing_by_column[header],
                "unique": len(set(nums)),
                "statistics": {
                    "mean": statistics.mean(nums) if nums else None,
                    "median": statistics.median(nums) if nums else None,
                    "min": min(nums) if nums else None,
                    "q1": _quantile(nums, 0.25) if nums else None,
                    "q3": _quantile(nums, 0.75) if nums else None,
                    "max": max(nums) if nums else None,
                    "stdev": statistics.stdev(nums) if len(nums) > 1 else 0.0 if nums else None,
                },
                "values": nums,
            }
        else:
            categorical_columns.append(header)
            counts = Counter(values)
            column_details[header] = {
                "type": "categorical",
                "non_missing": len(values),
                "missing": missing_by_column[header],
                "unique": len(set(values)),
                "top_values": [{"value": value, "count": count} for value, count in counts.most_common(8)],
                "values": values,
            }

    duplicate_count = len(clean_rows) - len({tuple(row[h] for h in headers) for row in clean_rows})
    correlations: list[dict[str, Any]] = []
    for i, left in enumerate(numeric_columns):
        for right in numeric_columns[i + 1:]:
            paired = [
                (_to_number(row[left]), _to_number(row[right]))
                for row in clean_rows
                if row[left] and row[right]
            ]
            pairs = [(x, y) for x, y in paired if x is not None and y is not None]
            corr = _correlation([x for x, _ in pairs], [y for _, y in pairs])
            if corr is not None:
                correlations.append({"left": left, "right": right, "correlation": corr, "n": len(pairs)})
    correlations.sort(key=lambda item: abs(item["correlation"]), reverse=True)

    overview = {
        "rows": len(clean_rows),
        "columns": len(headers),
        "numeric_columns": len(numeric_columns),
        "categorical_columns": len(categorical_columns),
        "missing_cells": sum(missing_by_column.values()),
        "duplicate_rows": duplicate_count,
    }
    # Hide raw value arrays in the public report payload; charts are derived separately.
    public_columns: dict[str, Any] = {}
    for header, details in column_details.items():
        public_columns[header] = {k: v for k, v in details.items() if k != "values"}

    charts: dict[str, Any] = {}
    for header in numeric_columns:
        values = column_details[header]["values"]
        # Histogram with up to 8 bins; constant columns become one bin.
        low, high = min(values), max(values)
        bin_count = min(8, max(1, round(math.sqrt(len(values)))))
        if low == high:
            bins = [{"label": _fmt_num(low), "count": len(values)}]
        else:
            width = (high - low) / bin_count
            counts = [0] * bin_count
            for value in values:
                idx = min(int((value - low) / width), bin_count - 1)
                counts[idx] += 1
            bins = []
            for idx, count in enumerate(counts):
                start = low + idx * width
                end = low + (idx + 1) * width
                bins.append({"label": f"{_fmt_num(start)}–{_fmt_num(end)}", "count": count})
        charts[header] = bins

    for header in categorical_columns:
        charts[header] = column_details[header]["top_values"][:6]

    return {
        "dataset": overview,
        "columns": public_columns,
        "column_order": headers,
        "numeric_columns": numeric_columns,
        "categorical_columns": categorical_columns,
        "correlations": correlations[:20],
        "charts": charts,
    }


def analyze_csv(path: str | Path) -> dict[str, Any]:
    path = Path(path)
    try:
        with path.open("r", encoding="utf-8-sig", newline="") as file:
            reader = csv.DictReader(file)
            headers = reader.fieldnames or []
            rows = list(reader)
    except UnicodeDecodeError as exc:
        raise ValueError("CSV must be UTF-8 encoded.") from exc
    except csv.Error as exc:
        raise ValueError(f"Could not parse CSV: {exc}") from exc
    if not headers:
        raise ValueError("The CSV file must include a header row.")
    if any(header is None or not header.strip() for header in headers):
        raise ValueError("CSV column names cannot be empty.")
    headers = [header.strip() for header in headers]
    return analyze_rows(headers, rows)


def write_json_report(result: dict[str, Any], path: str | Path) -> None:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(result, indent=2, ensure_ascii=False, allow_nan=False) + "\n", encoding="utf-8")


def _svg_bar_chart(items: list[tuple[str, float]], width: int = 620, height: int = 230) -> str:
    if not items:
        return '<p class="muted">No chart data available.</p>'
    max_value = max(value for _, value in items) or 1
    left, right, top, bottom = 165, 24, 16, 28
    plot_width = width - left - right
    row_height = (height - top - bottom) / len(items)
    parts = [f'<svg viewBox="0 0 {width} {height}" role="img" aria-label="Bar chart">']
    for idx, (label, value) in enumerate(items):
        y = top + idx * row_height
        bar_width = max(0.0, plot_width * value / max_value)
        safe_label = html.escape(str(label)[:24])
        parts.append(f'<text x="{left - 10}" y="{y + row_height * .65:.1f}" text-anchor="end" class="chart-label">{safe_label}</text>')
        parts.append(f'<rect x="{left}" y="{y + row_height * .18:.1f}" width="{bar_width:.2f}" height="{row_height * .58:.1f}" rx="4" class="bar"/>')
        parts.append(f'<text x="{min(left + bar_width + 7, width - right):.1f}" y="{y + row_height * .62:.1f}" class="chart-value">{_fmt_num(value)}</text>')
    parts.append("</svg>")
    return "".join(parts)


def write_html_dashboard(result: dict[str, Any], path: str | Path, title: str = "InsightForge Data Report") -> None:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    dataset = result["dataset"]
    metrics = [
        ("Rows", dataset["rows"]),
        ("Columns", dataset["columns"]),
        ("Missing cells", dataset["missing_cells"]),
        ("Duplicate rows", dataset["duplicate_rows"]),
    ]
    metric_cards = "".join(
        f'<article class="metric"><span>{html.escape(label)}</span><strong>{value:,}</strong></article>'
        for label, value in metrics
    )

    quality_rows = []
    for name in result["column_order"]:
        details = result["columns"][name]
        quality_rows.append(
            "<tr>"
            f"<td>{html.escape(name)}</td><td>{html.escape(details['type'].title())}</td>"
            f"<td>{details['non_missing']:,}</td><td>{details['missing']:,}</td>"
            f"<td>{details['unique']:,}</td></tr>"
        )

    chart_cards = []
    for name in result["column_order"]:
        details = result["columns"][name]
        if details["type"] == "numeric":
            bins = result["charts"][name]
            items = [(item["label"], item["count"]) for item in bins]
            chart_content = _svg_bar_chart(items)
            stat = details["statistics"]
            summary = (
                f"Mean <b>{_fmt_num(stat['mean'])}</b> · Median <b>{_fmt_num(stat['median'])}</b> · "
                f"Range <b>{_fmt_num(stat['min'])}–{_fmt_num(stat['max'])}</b>"
            )
            subtitle = "Distribution"
        else:
            top = result["charts"][name]
            items = [(item["value"], item["count"]) for item in top]
            chart_content = _svg_bar_chart(items)
            summary = f"{details['unique']:,} unique values · {details['missing']:,} missing"
            subtitle = "Most frequent values"
        chart_cards.append(
            f'<article class="panel"><div class="panel-head"><div><p class="eyebrow">{subtitle}</p>'
            f'<h3>{html.escape(name)}</h3></div><span class="pill">{details["type"]}</span></div>'
            f'<p class="summary">{summary}</p>{chart_content}</article>'
        )

    correlation_rows = []
    for item in result["correlations"][:10]:
        value = item["correlation"]
        strength = "Strong" if abs(value) >= .7 else "Moderate" if abs(value) >= .4 else "Weak"
        direction = "positive" if value > 0 else "negative"
        correlation_rows.append(
            f"<tr><td>{html.escape(item['left'])}</td><td>{html.escape(item['right'])}</td>"
            f"<td>{value:+.3f}</td><td>{strength} {direction}</td><td>{item['n']}</td></tr>"
        )
    if not correlation_rows:
        correlation_rows.append('<tr><td colspan="5" class="muted">No valid numeric correlations found.</td></tr>')

    html_doc = f"""<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>{html.escape(title)}</title>
<style>
:root{{--bg:#0b1020;--surface:#131b2e;--surface2:#19243a;--text:#edf2ff;--muted:#9eabc4;--accent:#7c9cff;--line:#293650;--green:#73e0bf}}
*{{box-sizing:border-box}}body{{margin:0;background:radial-gradient(ellipse at top left,#1b2b4a 0,#0b1020 45%);color:var(--text);font:15px/1.55 Inter,ui-sans-serif,system-ui,-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif}}
main{{max-width:1240px;margin:auto;padding:36px 24px 64px}}.hero{{display:flex;justify-content:space-between;gap:24px;align-items:flex-end;margin-bottom:28px;flex-wrap:wrap}}
.eyebrow{{text-transform:uppercase;letter-spacing:.15em;font-size:11px;color:var(--green);font-weight:800;margin:0 0 8px}}h1{{font-size:clamp(30px,5vw,48px);letter-spacing:-.04em;line-height:1.08;margin:0;max-width:760px}}.hero p.desc{{color:var(--muted);max-width:650px;margin:14px 0 0}}
.stamp{{border:1px solid var(--line);border-radius:12px;padding:10px 14px;color:var(--muted);font-size:12px;white-space:nowrap}}
.metrics{{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:14px;margin:24px 0 34px}}.metric,.panel,.section-box{{background:linear-gradient(145deg,rgba(25,36,58,.96),rgba(17,25,43,.96));border:1px solid var(--line);border-radius:18px;box-shadow:0 12px 30px rgba(0,0,0,.12)}}.metric{{padding:20px}}.metric span{{display:block;color:var(--muted);font-size:13px}}.metric strong{{display:block;font-size:32px;letter-spacing:-.04em;margin-top:5px}}
.section-title{{display:flex;align-items:end;justify-content:space-between;gap:16px;margin:36px 0 16px}}h2{{font-size:23px;letter-spacing:-.025em;margin:0}}.section-title p{{margin:4px 0 0;color:var(--muted);font-size:13px}}
.charts{{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:16px}}.panel{{padding:20px;min-width:0}}.panel-head{{display:flex;justify-content:space-between;gap:12px;align-items:center}}h3{{margin:0;font-size:19px;overflow-wrap:anywhere}}.panel-head .eyebrow{{margin-bottom:3px}}.pill{{border-radius:999px;background:#253453;color:#c4d2ff;padding:4px 9px;font-size:11px;text-transform:uppercase;letter-spacing:.05em}}.summary{{color:var(--muted);font-size:12px;margin:12px 0 8px}}.summary b{{color:var(--text)}}svg{{width:100%;height:auto;overflow:visible}}.chart-label{{fill:#b8c4db;font-size:11px}}.chart-value{{fill:#edf2ff;font-size:11px}}.bar{{fill:#7c9cff;opacity:.88}}.bar:hover{{fill:#73e0bf}}
.table-wrap{{overflow:auto;border:1px solid var(--line);border-radius:14px}}table{{width:100%;border-collapse:collapse;min-width:520px;background:rgba(19,27,46,.8)}}th,td{{padding:13px 16px;text-align:left;border-bottom:1px solid var(--line);font-size:13px}}th{{color:var(--muted);font-size:11px;text-transform:uppercase;letter-spacing:.08em;background:var(--surface2)}}tr:last-child td{{border-bottom:0}}td:nth-child(n+3){{font-variant-numeric:tabular-nums}}.muted{{color:var(--muted)}}footer{{margin-top:42px;padding-top:18px;border-top:1px solid var(--line);color:var(--muted);font-size:12px;display:flex;justify-content:space-between;gap:12px;flex-wrap:wrap}}
@media(max-width:760px){{main{{padding:24px 14px 42px}}.metrics{{grid-template-columns:repeat(2,minmax(0,1fr))}}.charts{{grid-template-columns:1fr}}.metric{{padding:16px}}.metric strong{{font-size:26px}}}}
</style>
</head>
<body><main>
<header class="hero"><div><p class="eyebrow">Day 100 · Data science capstone</p><h1>{html.escape(title)}</h1><p class="desc">A practical, reproducible overview of dataset quality, feature distributions, and relationships between numeric variables.</p></div><div class="stamp">INSIGHTFORGE / CSV ANALYTICS</div></header>
<section class="metrics" aria-label="Dataset overview">{metric_cards}</section>
<div class="section-title"><div><h2>Column profile</h2><p>Data types, completeness, and cardinality at a glance.</p></div></div>
<div class="table-wrap"><table><thead><tr><th>Column</th><th>Type</th><th>Present</th><th>Missing</th><th>Unique</th></tr></thead><tbody>{''.join(quality_rows)}</tbody></table></div>
<div class="section-title"><div><h2>Feature explorer</h2><p>Numeric distributions and top categorical values.</p></div></div>
<section class="charts">{''.join(chart_cards) if chart_cards else '<p class="muted">No chartable columns found.</p>'}</section>
<div class="section-title"><div><h2>Correlation signals</h2><p>Pearson correlation for numeric feature pairs with sufficient variation.</p></div></div>
<div class="table-wrap"><table><thead><tr><th>Feature A</th><th>Feature B</th><th>Pearson r</th><th>Interpretation</th><th>Pairs</th></tr></thead><tbody>{''.join(correlation_rows)}</tbody></table></div>
<footer><span>Generated by InsightForge · Python standard library</span><span>Explore carefully: correlation does not imply causation.</span></footer>
</main></body></html>"""
    path.write_text(html_doc, encoding="utf-8")
