from __future__ import annotations

import argparse
from pathlib import Path
import sys

from src.insightforge import analyze_csv, write_json_report, write_html_dashboard


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="InsightForge: analyze a CSV and generate a JSON summary + HTML dashboard."
    )
    parser.add_argument(
        "csv",
        nargs="?",
        default=None,
        help="Path to the input CSV file. Defaults to the bundled sample dataset when --demo is used.",
    )
    parser.add_argument("--demo", action="store_true", help="Analyze the bundled sample retail dataset.")
    parser.add_argument("--out", default="reports", help="Output directory (default: reports).")
    parser.add_argument("--title", default="InsightForge Data Report", help="Dashboard title.")
    return parser


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    if args.demo:
        csv_path = Path(__file__).parent / "data" / "sample_sales.csv"
    elif args.csv:
        csv_path = Path(args.csv)
    else:
        print("Error: provide a CSV path or use --demo.", file=sys.stderr)
        return 2

    if not csv_path.is_file():
        print(f"Error: CSV file not found: {csv_path}", file=sys.stderr)
        return 2

    try:
        result = analyze_csv(csv_path)
        out_dir = Path(args.out)
        out_dir.mkdir(parents=True, exist_ok=True)
        json_path = out_dir / "analysis.json"
        html_path = out_dir / "dashboard.html"
        write_json_report(result, json_path)
        write_html_dashboard(result, html_path, title=args.title)
    except (OSError, ValueError) as exc:
        print(f"Analysis failed: {exc}", file=sys.stderr)
        return 1

    print(f"Dataset: {csv_path}")
    print(f"Rows: {result['dataset']['rows']} | Columns: {result['dataset']['columns']}")
    print(f"JSON report: {json_path}")
    print(f"HTML dashboard: {html_path}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
