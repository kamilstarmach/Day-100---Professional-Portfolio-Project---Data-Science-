# Day 100 — InsightForge: Data Science Portfolio Project

InsightForge is a portfolio-ready, dependency-free data science application that turns a CSV dataset into a structured analysis and an interactive HTML dashboard.

## What it does

- Loads and validates CSV files.
- Profiles dataset dimensions, data types, missing values, duplicate rows, and column roles.
- Computes descriptive statistics for numeric columns and frequency summaries for categorical columns.
- Calculates Pearson correlations between numeric features.
- Produces an analysis JSON file and a standalone HTML dashboard with SVG charts.
- Includes a sample retail sales dataset so you can run the project immediately.
- Includes automated unit tests.

## Requirements

- Python 3.10+
- No third-party packages required.

## Quick start

```bash
python main.py --demo
```

This analyzes `data/sample_sales.csv` and writes:

- `reports/analysis.json`
- `reports/dashboard.html`

Open `reports/dashboard.html` in your browser.

## Analyze your own dataset

```bash
python main.py data/your_dataset.csv --out reports --title "My Dataset Analysis"
```

Optional arguments:

```bash
python main.py --help
```

## Run tests

```bash
python -m unittest discover -s tests -v
```

## Project structure

```text
day100_data_science/
├── main.py
├── README.md
├── requirements.txt
├── .gitignore
├── data/
│   └── sample_sales.csv
├── reports/
│   └── .gitkeep
├── src/
│   ├── __init__.py
│   └── insightforge.py
└── tests/
    └── test_insightforge.py
```

## How the analysis works

InsightForge uses only Python's standard library. It infers numeric columns from values that can be parsed consistently, ignores blank cells when calculating statistics, and reports missing values explicitly. Pearson correlation is calculated pairwise for numeric columns with at least three paired observations and non-zero variance.

The HTML report is self-contained: charts are rendered as SVG, so there are no external assets or network requests.

## Suggested portfolio extensions

- Add a pandas backend for larger datasets.
- Add configurable date parsing and time-series analysis.
- Add a predictive model and train/test evaluation.
- Add export to PDF or a Streamlit interface.
- Add a dataset comparison mode.

## License

MIT
