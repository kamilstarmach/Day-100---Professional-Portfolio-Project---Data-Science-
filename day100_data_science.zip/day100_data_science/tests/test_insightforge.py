import json
import tempfile
import unittest
from pathlib import Path

from src.insightforge import analyze_csv, analyze_rows, write_html_dashboard, write_json_report


class InsightForgeTests(unittest.TestCase):
    def test_numeric_statistics(self):
        result = analyze_rows(["sales"], [{"sales": "10"}, {"sales": "20"}, {"sales": "30"}])
        stats = result["columns"]["sales"]["statistics"]
        self.assertEqual(stats["mean"], 20)
        self.assertEqual(stats["median"], 20)
        self.assertEqual(stats["min"], 10)
        self.assertEqual(stats["max"], 30)

    def test_missing_values_are_counted(self):
        result = analyze_rows(["x", "group"], [
            {"x": "1", "group": "A"},
            {"x": "", "group": "B"},
            {"x": "3", "group": ""},
        ])
        self.assertEqual(result["dataset"]["missing_cells"], 2)
        self.assertEqual(result["columns"]["x"]["missing"], 1)
        self.assertEqual(result["columns"]["group"]["missing"], 1)

    def test_categorical_frequency_order(self):
        result = analyze_rows(["city"], [
            {"city": "Oslo"}, {"city": "Paris"}, {"city": "Oslo"}, {"city": "Rome"}
        ])
        self.assertEqual(result["charts"]["city"][0], {"value": "Oslo", "count": 2})

    def test_duplicate_rows(self):
        result = analyze_rows(["a"], [{"a": "x"}, {"a": "x"}, {"a": "y"}])
        self.assertEqual(result["dataset"]["duplicate_rows"], 1)

    def test_correlation(self):
        result = analyze_rows(["x", "y"], [
            {"x": "1", "y": "2"}, {"x": "2", "y": "4"}, {"x": "3", "y": "6"}
        ])
        self.assertAlmostEqual(result["correlations"][0]["correlation"], 1.0)

    def test_rejects_duplicate_headers(self):
        with self.assertRaises(ValueError):
            analyze_rows(["x", "x"], [{"x": "1"}])

    def test_csv_and_reports(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            csv_path = root / "data.csv"
            csv_path.write_text("name,value\nA,1\nB,2\n", encoding="utf-8")
            result = analyze_csv(csv_path)
            json_path = root / "analysis.json"
            html_path = root / "dashboard.html"
            write_json_report(result, json_path)
            write_html_dashboard(result, html_path, "Test Dashboard")
            loaded = json.loads(json_path.read_text(encoding="utf-8"))
            self.assertEqual(loaded["dataset"]["rows"], 2)
            self.assertIn("Test Dashboard", html_path.read_text(encoding="utf-8"))
            self.assertIn("<svg", html_path.read_text(encoding="utf-8"))

    def test_empty_rows_rejected(self):
        with self.assertRaises(ValueError):
            analyze_rows(["x"], [])


if __name__ == "__main__":
    unittest.main()
